/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemateatroasiento;

import java.util.Scanner;

/**
 *
 * @author Eric Hidalgo S6, me guie mas la clase anteior que el eclipse medio diferente
 */
public class SistemaTeatroAsiento {

    static int totalEntradasVendidas = 0;
    static double totalIngresos = 0;
    static final double PRECIO_ENTRADA = 5000;  // Precio por entrada

    boolean[] asientos = new boolean[10]; // Arreglo para gestionar si el asiento está ocupado
    String[] boletas = new String[10];  // Arreglo para almacenar la información de las boletas
    Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        SistemaTeatroAsiento sistema = new SistemaTeatroAsiento();
        sistema.inicializarAsientos();
        sistema.menu();
    }

    public void inicializarAsientos() {
        for (int i = 0; i < asientos.length; i++) {
            asientos[i] = false;  // Inicializa todos los asientos como disponibles
        }
    }

    public void menu() {
        int opcion;
        do {
            System.out.println("\n--- SISTEMA TEATRO ---");
            System.out.println("1. Reservar entrada");
            System.out.println("2. Comprar entrada");
            System.out.println("3. Modificar venta");
            System.out.println("4. Imprimir boleta");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1 -> reservarEntrada();
                case 2 -> comprarEntrada();
                case 3 -> modificarVenta();
                case 4 -> imprimirBoleta();
                case 5 -> System.out.println("Gracias por usar el sistema.");
                default -> System.out.println("Opcion invalida. Intente nuevamente.");
            }
        } while (opcion != 5);
    }

    public void reservarEntrada() {
        System.out.print("Seleccione el numero de asiento (1 a 10): ");
        int asientoSeleccionado = sc.nextInt() - 1;

        if (asientoSeleccionado < 0 || asientoSeleccionado >= asientos.length) {
            System.out.println("Asiento no valido.");
        } else if (asientos[asientoSeleccionado]) {
            System.out.println("El asiento ya esta reservado.");
        } else {
            asientos[asientoSeleccionado] = true;
            System.out.println("Asiento " + (asientoSeleccionado + 1) + " reservado con exito.");
            System.out.println("Precio de la entrada: " + PRECIO_ENTRADA);
        }
    }

    public void comprarEntrada() {
        System.out.print("Seleccione el numero de asiento para comprar (1 a 10): ");
        int asientoSeleccionado = sc.nextInt() - 1;

        if (asientoSeleccionado < 0 || asientoSeleccionado >= asientos.length) {
            System.out.println("Asiento no valido.");
        } else if (!asientos[asientoSeleccionado]) {
            System.out.println("El asiento no esta reservado, no se puede comprar.");
        } else {
            asientos[asientoSeleccionado] = false;  // Libera el asiento
            totalEntradasVendidas++;
            totalIngresos += PRECIO_ENTRADA;
            boletas[asientoSeleccionado] = "Asiento: " + (asientoSeleccionado + 1) + " - Precio: " + PRECIO_ENTRADA + "Estado: Vendido";
            System.out.println("Compra realizada con exito.");
        }
    }

    public void imprimirBoleta() {
        System.out.print("Ingrese el numero de asiento para imprimir la boleta: ");
        int asientoSeleccionado = sc.nextInt() - 1;

        if (asientoSeleccionado < 0 || asientoSeleccionado >= asientos.length) {
            System.out.println("Asiento no valido.");
        } else if (boletas[asientoSeleccionado] == null) {
            System.out.println("Este asiento no ha sido comprado.");
        } else {
            System.out.println(boletas[asientoSeleccionado]);
        }
    }

    public void modificarVenta() {
        System.out.println("Funcionalidad para modificar la venta aun no implementada.");
    }
}